a genAI powered fashion outfit generator
